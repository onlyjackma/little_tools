    
        $(document).ready(function () {
            $("#username").focus();//输入焦点
            $("#username").keydown(function (event) {
                if (event.which == "13") {//回车键,移动光标到密码框
                    $("#passwd").focus();
                }
            });
            $("#passwd").keydown(function (event) {
                if (event.which == "13") {//回车键，用.ajax提交表单
                    $("#loginbutton").trigger("click");
                }
            });
            $("#loginbutton").click(function () { //“登录”按钮单击事件
                //获取用户名称
                var strTxtName = encodeURI($("#username").val());
                //获取输入密码
                var strTxtPass = encodeURI($("#passwd").val());
                //开始发送数据
                $.ajax
                ({ //请求登录处理页
                    type:"POST",
                    url: "login", //登录处理页
                   // dataType: "html",
                    //传送请求数据
                    data: { txtName: strTxtName, txtPass: strTxtPass },
                    success: function (strValue) { //登录成功后返回的数据
                        //根据返回值进行状态显示
                        if (strValue == "True") {//注意是True,不是true
                            $(".clsShow").html("操作提示，登录成功！" + strValue);
                        }
                        else {
                            $("#divError").show().html("用户名或密码错误！" + strValue);
                        }
                    }
                })
            })
        });
